﻿Imports System.Data.OleDb
Public Class Form4

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a
        a = MsgBox("Are you sure, You want to quit?", MsgBoxStyle.YesNo)
        If a = 6 Then
            Form1.Show()
            Me.Hide()
        End If

    End Sub
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BloodbankTableAdapter.Fill(Me.BloodBankDataSet.bloodbank)
        Me.Validate()
        Me.BloodbankBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.BloodBankDataSet)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.BloodbankTableAdapter.Fill(Me.BloodBankDataSet.bloodbank)
        Me.Validate()
        Me.BloodbankBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.BloodBankDataSet)

    End Sub
End Class