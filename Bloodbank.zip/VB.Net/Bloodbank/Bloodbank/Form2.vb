﻿Imports System.Data.OleDb
Public Class Form2
    Dim dbc As New OleDbConnection
    Dim db As OleDbDataReader
    Dim cmd As New OleDbCommand

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a
        Dim c As Integer
        Dim z As Integer
        c = 0
        If TextBox1.Text = "" Then
            Dim b
            b = InputBox("Please enter the Patient ID :")
            z = MsgBox("Are you sure?", MsgBoxStyle.YesNo)
            If z = 6 Then
                c = c + 1
                cmd.CommandText = "delete from bloodbank where pid =" & b
                cmd.ExecuteNonQuery()
                MsgBox("Data Removed")
            End If
        End If
        If c = 0 Then
            a = MsgBox("Are you sure?", MsgBoxStyle.YesNo)
            If a = 6 Then
                cmd.CommandText = "delete from bloodbank where pid =" & Trim(TextBox1.Text)
                cmd.ExecuteNonQuery()
                MsgBox("Data Removed")
                TextBox1.Clear()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim b
        b = MsgBox("Are you sure, You want to quit?", MsgBoxStyle.YesNo)
        If b = 6 Then
            Form1.Show()
            Me.Hide()
        End If
        End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dbc.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\DOC\College files\PROJECT\VB.Net\DataBase\BloodBank.accdb;Persist Security Info=True"
        cmd.Connection = dbc
        dbc.Open()
        MsgBox("Removal Form Loaded!")
    End Sub

End Class