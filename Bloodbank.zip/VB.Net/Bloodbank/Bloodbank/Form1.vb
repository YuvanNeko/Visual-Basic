﻿Imports System.Data.OleDb
Public Class Form1
    Dim dbc As New OleDbConnection
    Dim db As OleDbDataReader
    Dim cmd As New OleDbCommand
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim a
        a = MsgBox("Are you sure, you want to quit?", MsgBoxStyle.YesNo)
        If (a = 6) Then
            End
        End If
    End Sub

    Private Sub InfoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InfoToolStripMenuItem.Click
        Form3.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Dim a
        a = MsgBox("Are you sure, you want to Cancel?", MsgBoxStyle.YesNo)
        If (a = 6) Then
            End
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dbc.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\DOC\College files\PROJECT\VB.Net\DataBase\BloodBank.accdb;Persist Security Info=True"
        cmd.Connection = dbc
        dbc.Open()
        MsgBox("Connection Established!")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim w = 0
        If TextBox1.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If TextBox2.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If TextBox3.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If ComboBox1.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If ComboBox2.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If ComboBox3.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If TextBox6.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If TextBox7.Text = "" Then
            MsgBox("Please fill all the values!")
            w = w + 1
        End If
        If w = 0 Then
            cmd.CommandText = "insert into bloodbank values ('" & Trim(TextBox1.Text) & "','" & Trim(TextBox2.Text) & "','" & Trim(TextBox3.Text) & "','" & Trim(ComboBox1.Text) & "','" & Trim(ComboBox3.Text) & "','" & Trim(TextBox6.Text) & "','" & Trim(TextBox7.Text) & "','" & Trim(ComboBox2.Text) & "')"
            cmd.ExecuteNonQuery()
            MsgBox("Data Added")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
            ComboBox1.Text = ""
            ComboBox2.Text = ""
            ComboBox3.Text = ""
        End If
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Hide()
        MsgBox("Data Viewer Loaded!")
        Form4.Show()
    End Sub

    Private Sub ViewToolStripMenuItem_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem1.Click
        Dim a
        a = MsgBox("Are you sure, you want to quit?", MsgBoxStyle.YesNo)
        If a = 6 Then
            End
        End If
    End Sub
End Class
