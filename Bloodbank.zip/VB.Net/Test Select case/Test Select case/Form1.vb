﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a
        a = TextBox1.Text
        If a = "" Then
            a = "Null"
            Select Case a
                Case "Null"
                    TextBox2.Text = "Null"
            End Select
        Else
            MsgBox(a)
        End If


    End Sub
End Class
